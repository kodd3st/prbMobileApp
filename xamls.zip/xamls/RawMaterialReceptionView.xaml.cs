using Microsoft.Win32;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using UWSR09_DesktopApp.Services;

namespace UWSR09_DesktopApp.Views
{
    public partial class RawMaterialReceptionView : Page
    {
        public RawMaterialReceptionView()
        {
            InitializeComponent();
            LoadBatches();
        }

        private void LoadBatches()
        {
            var batches = DBConn.db.RawMaterialBatches.ToList();
            DgBatches.ItemsSource = batches;
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadBatches();
        }

        private void BtnImport_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog { Filter = "Text files (*.txt)|*.txt" };
            if (dialog.ShowDialog() == true)
            {
                var lines = File.ReadAllLines(dialog.FileName, System.Text.Encoding.UTF8);
                var batches = new List<RawMaterialBatch>();

                for (int i = 1; i < lines.Length; i++)
                {
                    var fields = lines[i].Split(',');
                    if (fields.Length < 10) continue;

                    var batch = new RawMaterialBatch
                    {
                        ID_партии = fields[0],
                        ID_поставщика = fields[1],
                        Тип_сырья = fields[2],
                        Масса_брутто_кг = decimal.Parse(fields[3]),
                        Масса_тары_кг = decimal.Parse(fields[4]),
                        Масса_нетто_кг = decimal.Parse(fields[5]),
                        Дата_приемки = System.DateTime.Parse(fields[6]),
                        Время_приемки = System.TimeSpan.Parse(fields[7]),
                        Статус = fields[8],
                        Комментарий = fields.Length > 9 ? fields[9].Trim('"') : ""
                    };

                    var errors = ValidationService.ValidateBatch(
                        batch.ID_партии, batch.ID_поставщика, batch.Тип_сырья,
                        batch.Масса_брутто_кг, batch.Масса_тары_кг, batch.Масса_нетто_кг);

                    batch.Статус = ValidationService.DetermineBatchStatus(errors);
                    if (errors.Any())
                        batch.Комментарий = string.Join("; ", errors);

                    if (!DBConn.db.RawMaterialBatches.Any(b => b.ID_партии == batch.ID_партии))
                        batches.Add(batch);
                }

                DBConn.db.RawMaterialBatches.AddRange(batches);
                DBConn.db.SaveChanges();
                LoadBatches();
                MessageBox.Show($"Импортировано {batches.Count} записей.");
            }
        }
    }
}