using System.Windows.Controls;

namespace UWSR09_DesktopApp.Views
{
    public partial class FilmProductionView : Page
    {
        public FilmProductionView()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            DgTasks.ItemsSource = DBConn.db.ShiftTasks.ToList();
            DgLog.ItemsSource = DBConn.db.ProductionLogs.ToList();
        }
    }
}