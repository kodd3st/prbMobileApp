using System.Collections.Generic;
using System.Linq;

namespace UWSR09_DesktopApp.Services
{
    public static class ValidationService
    {
        public static List<string> ValidateBatch(string batchId, string supplierId, string materialType,
            decimal gross, decimal tare, decimal net)
        {
            var errors = new List<string>();

            if (tare < 0) errors.Add("Отрицательная масса тары");
            if (gross == 0 && tare == 0 && net == 0) errors.Add("Полностью нулевые значения");
            if (net == 0 && (gross > 0 || tare > 0)) errors.Add("Нулевая масса нетто при ненулевых брутто и таре");
            if (System.Math.Abs(gross - tare - net) > 0.01m) errors.Add("Несоответствие масс: брутто - тара ≠ нетто");
            if (gross > 100000) errors.Add("Нереальная масса брутто");
            if (gross == 0 && tare == 0) errors.Add("Нулевая масса");

            if (!DBConn.db.Suppliers.Any(s => s.ID_поставщика == supplierId))
                errors.Add("Несуществующий поставщик");

            if (materialType != "ПЭТ-хлопья")
                errors.Add("Неверный тип сырья");

            return errors;
        }

        public static string DetermineBatchStatus(List<string> errors)
        {
            return errors.Any() ? "Забракована" : "Одобрена";
        }
    }
}