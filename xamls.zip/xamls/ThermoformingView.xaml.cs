using System.Windows.Controls;

namespace UWSR09_DesktopApp.Views
{
    public partial class ThermoformingView : Page
    {
        public ThermoformingView()
        {
            InitializeComponent();
            LoadAll();
        }

        private void LoadAll()
        {
            DgThermo.ItemsSource = DBConn.db.WarehouseStock.ToList();
        }

        private void BtnSearch_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var id = TxtBatch.Text.Trim();
            var result = DBConn.db.WarehouseStock.Where(w => w.BatchID == id).ToList();
            DgThermo.ItemsSource = result;
        }
    }
}