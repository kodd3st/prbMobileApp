-- Удаляем БД, если существует (для чистой установки)
USE master;
IF DB_ID('YetiCupDB') IS NOT NULL
BEGIN
    ALTER DATABASE YetiCupDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE YetiCupDB;
END
GO

-- Создаём БД
CREATE DATABASE YetiCupDB;
GO

USE YetiCupDB;
GO

-- 1. Поставщики
CREATE TABLE Suppliers (
    ID_поставщика NVARCHAR(20) PRIMARY KEY,
    Название_поставщика NVARCHAR(255) NOT NULL,
    Контактное_лицо NVARCHAR(255),
    Телефон NVARCHAR(30),
    Email NVARCHAR(255),
    Статус NVARCHAR(50)
);

-- 2. Пользователи
CREATE TABLE Users (
    user_id NVARCHAR(20) PRIMARY KEY,
    username NVARCHAR(100),
    full_name NVARCHAR(255),
    role NVARCHAR(100),
    department NVARCHAR(100),
    email NVARCHAR(255),
    phone NVARCHAR(30),
    is_active BIT,
    access_level NVARCHAR(50),
    created_date DATE
);

-- 3. Типы вторсырья
CREATE TABLE MaterialTypes (
    material_code NVARCHAR(50) PRIMARY KEY,
    material_name NVARCHAR(255),
    material_category NVARCHAR(50),
    description NVARCHAR(1000)
);

-- 4. Посторонние полимеры (для муфельной печи)
CREATE TABLE ForeignPolymers (
    polymer_name NVARCHAR(100) PRIMARY KEY,
    category NVARCHAR(50),
    detection_method NVARCHAR(100),
    melting_point NVARCHAR(50),
    max_tolerance_ppm INT,
    risk_level NVARCHAR(20),
    description NVARCHAR(1000)
);

-- 5. Приемка сырья (Сессия 1)
CREATE TABLE RawMaterialBatches (
    ID_партии NVARCHAR(50) PRIMARY KEY,
    ID_поставщика NVARCHAR(20) NOT NULL,
    Тип_сырья NVARCHAR(100),
    Масса_брутто_кг DECIMAL(10,2),
    Масса_тары_кг DECIMAL(10,2),
    Масса_нетто_кг DECIMAL(10,2),
    Дата_приемки DATE,
    Время_приемки TIME,
    Статус NVARCHAR(50),
    Комментарий NVARCHAR(1000),
    FOREIGN KEY (ID_поставщика) REFERENCES Suppliers(ID_поставщика)
);

-- 6. Результаты тестов (Сессия 1 — влажность, плотность, печь)
CREATE TABLE AcceptanceTests (
    test_id INT IDENTITY(1,1) PRIMARY KEY,
    ID_партии NVARCHAR(50) NOT NULL,
    test_name NVARCHAR(100), -- 'Влажность', 'Плотность', 'Термическое испытание', 'Анализ пожелтения'
    test_result NVARCHAR(255), -- 'Пройден/Не пройден' или числовое значение
    test_value DECIMAL(10,4), -- для числовых тестов
    performed_by NVARCHAR(20),
    test_date DATETIME,
    FOREIGN KEY (ID_партии) REFERENCES RawMaterialBatches(ID_партии),
    FOREIGN KEY (performed_by) REFERENCES Users(user_id)
);

-- 7. Этапы производства (справочник)
CREATE TABLE ProductionStages (
    stage_name NVARCHAR(100) PRIMARY KEY
);

-- 8. Пресс-формы
CREATE TABLE Molds (
    mold_code NVARCHAR(50) PRIMARY KEY,
    mold_name NVARCHAR(255),
    heating_temperature INT,
    holding_time DECIMAL(3,1),
    parts_per_cycle INT,
    description NVARCHAR(1000)
);

-- 9. Журнал производства (Сессия 2 и 3)
CREATE TABLE ProductionLogs (
    log_id INT IDENTITY(1,1) PRIMARY KEY,
    batch_id NVARCHAR(50) NOT NULL,
    stage NVARCHAR(100) NOT NULL,
    timestamp DATETIME,
    operator_id NVARCHAR(20) NULL,
    width_mm INT NULL,
    waste_kg DECIMAL(5,1) NULL,
    temperature_c INT NULL,
    thickness_mm DECIMAL(4,2) NULL,
    pressure_bar INT NULL,
    speed_m_min DECIMAL(4,1) NULL,
    status NVARCHAR(50),
    notes NVARCHAR(1000),
    FOREIGN KEY (batch_id) REFERENCES RawMaterialBatches(ID_партии),
    FOREIGN KEY (operator_id) REFERENCES Users(user_id),
    FOREIGN KEY (stage) REFERENCES ProductionStages(stage_name)
);

-- 10. Дефекты пленки
CREATE TABLE FilmDefects (
    defect_code NVARCHAR(20) PRIMARY KEY,
    defect_name NVARCHAR(255),
    defect_category NVARCHAR(100),
    severity NVARCHAR(20),
    detection_method NVARCHAR(100),
    description NVARCHAR(1000),
    possible_causes NVARCHAR(1000),
    recommended_action NVARCHAR(1000)
);

-- 11. Сменные задания
CREATE TABLE ShiftTasks (
    task_id NVARCHAR(50) PRIMARY KEY,
    stage NVARCHAR(100),
    user_id NVARCHAR(20),
    username NVARCHAR(100),
    full_name NVARCHAR(255),
    role NVARCHAR(100),
    department NVARCHAR(100),
    email NVARCHAR(255),
    phone NVARCHAR(30),
    is_active BIT,
    access_level NVARCHAR(50),
    created_date DATE,
    assignment_date DATE,
    shift NVARCHAR(50),
    status NVARCHAR(50),
    priority NVARCHAR(50),
    batch_id NVARCHAR(50),
    equipment NVARCHAR(50),
    instructions NVARCHAR(1000),
    planned_hours INT,
    FOREIGN KEY (batch_id) REFERENCES RawMaterialBatches(ID_партии),
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
    FOREIGN KEY (stage) REFERENCES ProductionStages(stage_name)
);

-- 12. Склад готовой продукции (Сессия 3)
CREATE TABLE WarehouseStock (
    BatchID NVARCHAR(50) PRIMARY KEY,
    ProductionDate DATE,
    Product NVARCHAR(255),
    Cup_Size_ml INT,
    Quantity_Pcs INT,
    Pallets_Qty INT,
    Weight_kg DECIMAL(10,1),
    Warehouse_Location NVARCHAR(50),
    InvoiceID NVARCHAR(50),
    InvoiceDate DATE,
    Status NVARCHAR(100)
);

-- 13. Управление отгрузками (транспортные накладные)
CREATE TABLE Shipments (
    ShippingID NVARCHAR(50) PRIMARY KEY,
    InvoiceID NVARCHAR(50),
    BatchID NVARCHAR(50),
    ShippingDate DATE,
    Customer NVARCHAR(255),
    CustomerAddress NVARCHAR(500),
    Product NVARCHAR(255),
    Quantity_Pcs INT,
    Pallets_Qty INT,
    Weight_kg DECIMAL(10,1),
    Carrier NVARCHAR(255),
    DriverName NVARCHAR(255),
    VehicleNumber NVARCHAR(20),
    ShippingStatus NVARCHAR(50),
    DocumentDate DATE,
    FOREIGN KEY (BatchID) REFERENCES WarehouseStock(BatchID)
);

-- === Заполнение справочников ===

-- Этапы производства
INSERT INTO ProductionStages (stage_name) VALUES
(N'Регистрация'),
(N'Тестирование'),
(N'Растаривание'),
(N'Очистка'),
(N'Формирование пленки'),
(N'Контроль качества пленки'),
(N'Термоформовка стаканчиков');

-- Типы тестов (для внешней ссылки или логики)
-- Можно использовать как ENUM через отдельную таблицу, но в задании это список
-- Здесь просто упомянуто для бизнес-логики

-- Создание индексов (опционально, для производительности)
CREATE INDEX IX_ProductionLogs_Batch ON ProductionLogs(batch_id);
CREATE INDEX IX_RawMaterialBatches_Status ON RawMaterialBatches(Статус);
CREATE INDEX IX_WarehouseStock_Batch ON WarehouseStock(BatchID);

GO