using System.Windows;

namespace UWSR09_DesktopApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnSession1_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new Views.RawMaterialReceptionView());
        }

        private void BtnSession2_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new Views.FilmProductionView());
        }

        private void BtnSession3_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new Views.ThermoformingView());
        }

        private void BtnWarehouse_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new Views.WarehouseView());
        }
    }
}