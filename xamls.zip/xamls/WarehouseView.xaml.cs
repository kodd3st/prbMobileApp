using System.Windows.Controls;

namespace UWSR09_DesktopApp.Views
{
    public partial class WarehouseView : Page
    {
        public WarehouseView()
        {
            InitializeComponent();
            DgShipments.ItemsSource = DBConn.db.Shipments.ToList();
        }
    }
}