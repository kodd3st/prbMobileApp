﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoControl.infrastructure
{
    public class UserSession
    {
        private static UserSession _instance;
        public static UserSession Instance => _instance ?? (_instance = new UserSession());

        public int UserID { get; set; }
        public string Name { get; set; }
        public string SecondName { get; set; }
        public string Surname { get; set; }
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }
        public int RoleID { get; set; }
        public string RoleName { get; set; }

        private UserSession() { }
    }
}
