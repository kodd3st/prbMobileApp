﻿using DoControl.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoControl.infrastructure
{
    internal class DBConn
    {
        public static DocControlEntities db = new DocControlEntities();
    }
}
