﻿using DoControl.infrastructure;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DoControl
{
    /// <summary>
    /// Логика взаимодействия для registrationWindow.xaml
    /// </summary>
    public partial class registrationWindow : Window
    {
        public registrationWindow()
        {
            InitializeComponent();
            LoadDepartments();
            cmbDepartment.SelectedIndex = 0;
        }

        private void LoadDepartments()
        {
            try
            {
                var departments = DBConn.db.Departments.Where(d => d.DepartmentID != 9).OrderBy(d => d.DepartmentName).ToList();
                cmbDepartment.ItemsSource = departments;
                cmbDepartment.DisplayMemberPath = "DepartmentName";
                cmbDepartment.SelectedValuePath = "DepartmentID";

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки отделов: " + ex.Message);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            string login = txbLogin.Text;
            string password = psbPassword.Password;
            string confirmPassword = psbConfirmPass.Password;
            string name = txbName.Text;
            string secondName = txbSecondName.Text;
            string surname = txbSurname.Text;
            int departmentId = (int)cmbDepartment.SelectedValue;

            if (login == null || password == null || name == null || secondName == null || surname == null)
            {
                MessageBox.Show("Все поля должны быть заполнены");
            }
            if (password != confirmPassword)
            {
                MessageBox.Show("Пароли не совпадают");
            }
            else
            {
                if (DBConn.db.Users.Any(u => u.Login == login))
                {
                    MessageBox.Show("Пользователь с таким логином уже существует");
                }

                var newUser = new model.Users
                {
                    Login = login,
                    Password = password,
                    Name = name,
                    SecondName = secondName,
                    Surname = surname,
                    RoleID = 2,
                    DepartmentID = departmentId
                };

                DBConn.db.Users.Add(newUser);
                DBConn.db.SaveChanges();

                MessageBox.Show("Регистрация прошла успешно!");
                this.Close();
            }
        }
    }
}
