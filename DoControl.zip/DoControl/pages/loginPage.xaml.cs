﻿using DoControl.infrastructure;
using DoControl.model;
using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DoControl.pages
{
    public partial class loginPage : Page
    {
        public loginPage()
        {
            InitializeComponent();
            psbPassword.GotFocus += RemovePasswordPlaceholder;
            psbPassword.LostFocus += AddPasswordPlaceholder;
            txbEmail.GotFocus += RemoveEmailPlaceholder;
            txbEmail.LostFocus += AddEmailPlaceholder;
            txbPassword.GotFocus += PasswordTextBox_GotFocus;
        }

        private void RemovePasswordPlaceholder(object sender, RoutedEventArgs e)
        {
            if (psbPassword.Password == "Введите пароль...")
            {
                psbPassword.Password = "";
                psbPassword.Foreground = Brushes.Black;
            }
        }

        private void AddPasswordPlaceholder(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(psbPassword.Password))
            {
                psbPassword.Password = "Введите пароль...";
                psbPassword.Foreground = Brushes.Gray;
            }
        }

        private void RemoveEmailPlaceholder(object sender, RoutedEventArgs e)
        {
            if (txbEmail.Text == "email@mail.com")
            {
                txbEmail.Text = "";
                txbEmail.Foreground = Brushes.Black;
            }
        }

        private void AddEmailPlaceholder(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txbEmail.Text))
            {
                txbEmail.Text = "email@mail.com";
                txbEmail.Foreground = Brushes.Gray;
            }
        }


        private void PasswordTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            psbPassword.Focus();
        }

        private void btnTogglePassword_Click(object sender, RoutedEventArgs e)
        {
            if (psbPassword.Visibility == Visibility.Visible)
            {
                psbPassword.Visibility = Visibility.Collapsed;
                txbPassword.Visibility = Visibility.Visible;
                txbPassword.Text = psbPassword.Password;
            }
            else
            {
                psbPassword.Visibility = Visibility.Visible;
                txbPassword.Visibility = Visibility.Collapsed;
                psbPassword.Password = txbPassword.Text;
            }
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txbEmail.Text;
            string password = psbPassword.Password;
            Users findUser = CheckUser(login, password);
            if (findUser != null)
            {
                //сохраняем пользователя в сессии
                var session = UserSession.Instance;
                session.UserID = findUser.UserID;
                session.Name = findUser.Name;
                session.Surname = findUser.Surname;
                session.SecondName = findUser.SecondName;
                session.DepartmentID = findUser.DepartmentID;
                session.DepartmentName = findUser.Departments?.DepartmentName;
                session.RoleID = findUser.RoleID;
                session.RoleName = findUser.Roles?.RoleName;

                this.NavigationService.Navigate(new Uri("./pages/docControl.xaml", UriKind.RelativeOrAbsolute));
            }
            else
            {
                MessageBox.Show("Пользователя не существует.\nПроверьте правильность ввода логина пароля.\nЛогин и пароль чувствительны к регистру, не забывайте об этом");
            }
        }

        private void btnForgetPass_Click(object sender, RoutedEventArgs e)
        {
            string login = txbEmail.Text;

            if (login == null)
            {
                MessageBox.Show("Введите логин", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            else
            {
                var user = DBConn.db.Users.FirstOrDefault(u => u.Login == login);

                if (user != null)
                {
                    MessageBox.Show("Ваш пароль: " + user.Password, "Восстановление пароля");
                }
                else
                {
                    MessageBox.Show("Пользователь с таким логином не найден", "Ошибка");
                }
            }

        }

        private void btnSettings_Click(object sender, RoutedEventArgs e)
        {
            settingsWindow settingsWin = new settingsWindow();
            settingsWin.ShowDialog();
        }

        private Users CheckUser(string login, string password)
        {
            try
            {
                Users findUser = DBConn.db.Users.Where(u => u.Login == login && u.Password == password).FirstOrDefault();
                return findUser;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при проверке пользователя: {ex.Message}");
                return null;
            }
        }
    }
}
