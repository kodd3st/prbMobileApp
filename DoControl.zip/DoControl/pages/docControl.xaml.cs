﻿using DoControl.infrastructure;
using DoControl.pages.controlPages;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DoControl.pages
{
    /// <summary>
    /// Логика взаимодействия для docControl.xaml
    /// </summary>
    public partial class docControl : Page
    {
        public docControl()
        {
            InitializeComponent();
            DataContext = this;
            frmControlManager.Navigate(new Uri("./pages/controlPages/dashboardPage.xaml", UriKind.RelativeOrAbsolute));            
        }

        private void btnAddDoc_Click(object sender, RoutedEventArgs e)
        {
            frmControlManager.Navigate(new Uri("./pages/controlPages/docCreatePage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void logoButton_Click(object sender, RoutedEventArgs e)
        {
            frmControlManager.Navigate(new Uri("./pages/controlPages/dashboardPage.xaml", UriKind.RelativeOrAbsolute));

        }

        private void btnInbox_Click(object sender, RoutedEventArgs e)
        {
            frmControlManager.Navigate(new Uri("./pages/controlPages/inboxPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btnOutbox_Click(object sender, RoutedEventArgs e)
        {
            frmControlManager.Navigate(new Uri("./pages/controlPages/OutboxPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btnArchive_Click(object sender, RoutedEventArgs e)
        {
            frmControlManager.Navigate(new Uri("./pages/controlPages/archivePage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btnTemplates_Click(object sender, RoutedEventArgs e)
        {
            frmControlManager.Navigate(new Uri("./pages/controlPages/templatePage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("./pages/loginPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btnSettings_Click(object sender, RoutedEventArgs e)
        {
            settingsWindow settingsWin = new settingsWindow();
            settingsWin.ShowDialog();
        }

        private void btnRegistration_Click(object sender, RoutedEventArgs e)
        {
            registrationWindow regWindow = new registrationWindow();
            regWindow.ShowDialog();
        }

        public bool isAdmin
        {
            get
            {
                // Предположим, что у администратора RoleID == 1
                return UserSession.Instance.RoleID == 1;
                // Или если по имени: return UserSession.Instance.RoleName == "Администратор";
            }
        }
    }
}