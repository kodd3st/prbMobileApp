﻿using DoControl.infrastructure;
using DoControl.model;
using Microsoft.Win32;
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace DoControl.pages.controlPages
{
    /// <summary>
    /// Логика взаимодействия для docCreatePage.xaml
    /// </summary>
    public partial class docCreatePage : Page
    {
        private bool isTemplateMode = false;
        string filePathInfo = null;
        private Documents editingDocument;

        public docCreatePage()
        {
            InitializeComponent();
            lblEditPageName.Content = "Новый документ";
            LoadInfo();
        }
        public docCreatePage(bool isTemplate) : this()
        {
            isTemplateMode = isTemplate;
            lblEditPageName.Content = isTemplate ? "Новый шаблон" : "Новый документ";
        }
        public docCreatePage(Documents documentToEdit, bool isTemplate = false) : this()
        {
            isTemplateMode = isTemplate;
            editingDocument = documentToEdit;
            lblEditPageName.Content = isTemplate ? "Редактирование шаблона" : (editingDocument != null ? "Редактирование документа" : "Новый документ");
            if (editingDocument != null)
            {
                txbDocNum.Text = editingDocument.DocNumber;
                txbDocTheme.Text = editingDocument.Title;
                cmbDocType.SelectedValue = editingDocument.DocTypeID;
                cmbDepartment.SelectedValue = editingDocument.DepartmentID;
                dtpDocDate.SelectedDate = editingDocument.DateDeadLine;
                txbContent.Text = editingDocument.DocContent;
            }
        }
        private void LoadInfo()
        {
            using (var context = new DocControlEntities())
            {
                cmbDocType.ItemsSource = context.DocumentType.ToList();
                cmbDepartment.ItemsSource = context.Departments.ToList();
            }
        }

        private void btnSaveDoc_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var context = new DocControlEntities())
                {
                    if (editingDocument != null && isTemplateMode)
                    {
                        // Редактирование шаблона
                        var doc = context.Documents.FirstOrDefault(d => d.DocumentID == editingDocument.DocumentID);
                        if (doc != null)
                        {
                            doc.DocNumber = txbDocNum.Text;
                            doc.Title = txbDocTheme.Text;
                            doc.DocTypeID = (int)cmbDocType.SelectedValue;
                            doc.DepartmentID = (int)cmbDepartment.SelectedValue;
                            doc.InvestmentFile = filePathInfo;
                            doc.DateDeadLine = dtpDocDate.SelectedDate;
                            doc.DocContent = txbContent.Text;
                            doc.IsTemplate = 1;
                            context.SaveChanges();
                            MessageBox.Show("Шаблон успешно обновлён.", "Редактирование", MessageBoxButton.OK, MessageBoxImage.Information);
                            NavigationService.GoBack();
                        }
                    }
                    else if (editingDocument != null && !isTemplateMode)
                    {
                        // Создание документа на основе шаблона
                        var doc = new Documents
                        {
                            Title = txbDocTheme.Text,
                            DocTypeID = (int?)cmbDocType.SelectedValue ?? 0,
                            DepartmentID = (int?)cmbDepartment.SelectedValue,
                            StatusID = 1,
                            DateCreate = DateTime.Now,
                            DocNumber = txbDocNum.Text,
                            IsArchive = 0,
                            OutInID = 2,
                            DateDeadLine = dtpDocDate.SelectedDate,
                            IsTemplate = 0,
                            InvestmentFile = filePathInfo,
                            DocContent = txbContent.Text,
                            SenderID = UserSession.Instance.UserID,
                        };
                        context.Documents.Add(doc);
                        context.SaveChanges();
                        MessageBox.Show("Документ успешно создан на основе шаблона!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        NavigationService.GoBack();
                    }
                    else if (editingDocument == null && isTemplateMode)
                    {
                        // Создание нового шаблона
                        var doc = new Documents
                        {
                            Title = txbDocTheme.Text,
                            DocTypeID = (int?)cmbDocType.SelectedValue ?? 0,
                            DepartmentID = (int?)cmbDepartment.SelectedValue,
                            StatusID = 1,
                            DateCreate = DateTime.Now,
                            DocNumber = txbDocNum.Text,
                            IsArchive = 0,
                            OutInID = 2,
                            DateDeadLine = dtpDocDate.SelectedDate,
                            IsTemplate = 1,
                            InvestmentFile = filePathInfo,
                            DocContent = txbContent.Text,
                        };
                        context.Documents.Add(doc);
                        context.SaveChanges();
                        MessageBox.Show("Шаблон успешно сохранён!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        NavigationService.GoBack();
                    }
                    else if (editingDocument != null)
                    {
                        // Редактирование существующего документа
                        var doc = context.Documents.FirstOrDefault(d => d.DocumentID == editingDocument.DocumentID);
                        if (doc != null)
                        {
                            doc.DocNumber = txbDocNum.Text;
                            doc.Title = txbDocTheme.Text;
                            doc.DocTypeID = (int)cmbDocType.SelectedValue;
                            doc.DepartmentID = (int)cmbDepartment.SelectedValue;
                            doc.InvestmentFile = filePathInfo;
                            doc.DateDeadLine = dtpDocDate.SelectedDate;
                            doc.DocContent = txbContent.Text;
                            doc.IsTemplate = 0;
                            // и т.д. для остальных полей
                            context.SaveChanges();
                            MessageBox.Show("Документ успешно обновлён.", "Редактирование", MessageBoxButton.OK, MessageBoxImage.Information);
                            NavigationService.GoBack();
                        }
                    }
                    else
                    {
                        //новый документ
                        var doc = new Documents
                        {
                            Title = txbDocTheme.Text,
                            DocTypeID = (int?)cmbDocType.SelectedValue ?? 0,
                            DepartmentID = (int?)cmbDepartment.SelectedValue,
                            StatusID = 1,
                            DateCreate = DateTime.Now,
                            DocNumber = txbDocNum.Text,
                            IsArchive = 0,
                            OutInID = 2,
                            DateDeadLine = dtpDocDate.SelectedDate,
                            IsTemplate = 0,
                            InvestmentFile = filePathInfo,
                            DocContent = txbContent.Text,
                            SenderID = UserSession.Instance.UserID,
                        };

                        context.Documents.Add(doc);
                        context.SaveChanges();
                        MessageBox.Show("Документ успешно сохранён!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        NavigationService.GoBack();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении документа: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnAddDoc_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "All files (*.*)|*.*|Image files (*.jpg, *.png)|*.jpg;*.png";
            openFileDialog.FilterIndex = 2;

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    FileInfo fileInfo = new FileInfo(openFileDialog.FileName);

                    tbFileName.Text = "Имя файла: " + fileInfo.Name;
                    tbFileSize.Text = "Размер: " + GetFileSizeString(fileInfo.Length);
                    tbFileExtension.Text = "Расширение: " + fileInfo.Extension;
                    filePathInfo = fileInfo.DirectoryName + "\\" + fileInfo.Name;
                    tbFilePath.Text = "Путь: " + fileInfo.DirectoryName;

                    if (IsImageFile(fileInfo.Extension))
                    {
                        imgPreview.Visibility = Visibility.Visible;
                        imgPreview.Source = new BitmapImage(new Uri(fileInfo.FullName));
                    }
                    else
                    {
                        imgPreview.Visibility = Visibility.Collapsed;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при загрузке файла: " + ex.Message, "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private string GetFileSizeString(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            int order = 0;
            double len = bytes;

            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len = len / 1024;
            }

            return $"{len:0.##} {sizes[order]}";
        }

        private bool IsImageFile(string extension)
        {
            string[] imageExtensions = { ".jpg", ".jpeg", ".png", ".gif", ".bmp" };
            return Array.Exists(imageExtensions, ext => ext.Equals(extension, StringComparison.OrdinalIgnoreCase));
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
