﻿using DoControl.infrastructure;
using DoControl.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DoControl.pages.controlPages
{
    /// <summary>
    /// Логика взаимодействия для inboxPage.xaml
    /// </summary>
    public partial class inboxPage : Page
    {
        public List<Documents> IncomingDocuments { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        public inboxPage()
        {
            InitializeComponent();
            LoadIncomingDocuments();

            var cvs = (CollectionViewSource)this.Resources["DocsViewSource"];
            cvs.Filter += DocsViewSource_Filter;
        }

        private void LoadIncomingDocuments()
        {
            try
            {
                int departmentId = UserSession.Instance.DepartmentID;
                using (var context = new DocControlEntities())
                {
                    if (departmentId == 9)
                    {
                        IncomingDocuments = context.Documents.Where(d => d.OutInID == 1 && d.IsArchive == 0).ToList();
                    }
                    else
                    {
                        IncomingDocuments = context.Documents.Where(d => d.SenderID != UserSession.Instance.UserID && d.IsArchive == 0 && d.DepartmentID == departmentId).ToList();
                    }
                    cmbDocTypes.ItemsSource = context.DocumentType.ToList();

                    foreach (var doc in IncomingDocuments)
                    {
                        doc.DocumentType = context.DocumentType.FirstOrDefault(t => t.DocTypeID == doc.DocTypeID);

                        if (doc.DepartmentID.HasValue)
                        {
                            doc.Departments = context.Departments.FirstOrDefault(d => d.DepartmentID == doc.DepartmentID.Value);
                        }
                        doc.DocumentStatus = context.DocumentStatus.FirstOrDefault(s => s.StatusID == doc.StatusID);
                    }
                }
                DataContext = this;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки входящих документов: " + ex.Message);
            }
        }

        private void btnCancelFilters_Click(object sender, RoutedEventArgs e)
        {
            cmbDocTypes.SelectedIndex = -1;
            dtpStart.SelectedDate = null;
            dtpEnd.SelectedDate = null;
            var cvs = (CollectionViewSource)this.Resources["DocsViewSource"];
            cvs.View.Refresh();
            DataContext = null;
            LoadIncomingDocuments();
        }

        private void menuView_Click(object sender, RoutedEventArgs e)
        {
            var selectedDoc = lstInbox.SelectedItem as Documents;
            if (selectedDoc != null)
            {
                // Откройте окно просмотра или выполните нужное действие
                MessageBox.Show($"Просмотр документа: {selectedDoc.DocNumber}");
            }
            try
            {
                using (var context = new DocControlEntities())
                {
                    var doc = context.Documents.FirstOrDefault(d => d.DocumentID == selectedDoc.DocumentID);
                    if (doc != null)
                    {
                        if (doc.StatusID == 1)
                        {
                            doc.StatusID = 2;
                        }
                        context.SaveChanges();
                    }
                }
                DataContext = null;
                LoadIncomingDocuments();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка просмотра документа: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void menuRemove_Click(object sender, RoutedEventArgs e)
        {
            var selectedDoc = lstInbox.SelectedItem as Documents;
            if (selectedDoc == null)
            {
                MessageBox.Show("Пожалуйста, выберите документ для удаления.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var result = MessageBox.Show(
            $"Вы действительно хотите удалить документ №{selectedDoc.DocNumber}?",
            "Подтверждение удаления",
            MessageBoxButton.YesNo,
            MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
                return;

            try
            {
                using (var context = new DocControlEntities())
                {
                    var doc = context.Documents.FirstOrDefault(d => d.DocumentID == selectedDoc.DocumentID);
                    if (doc != null)
                    {
                        context.Documents.Remove(doc);
                        context.SaveChanges();
                    }
                }

                MessageBox.Show("Документ успешно удалён.", "Удаление", MessageBoxButton.OK, MessageBoxImage.Information);

                // Обновить список исходящих документов
                DataContext = null;
                LoadIncomingDocuments();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при удалении документа: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void menuArchive_Click(object sender, RoutedEventArgs e)
        {
            var selectedDoc = lstInbox.SelectedItem as Documents;
            if (selectedDoc == null)
            {
                MessageBox.Show("Пожалуйста, выберите документ.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var result = MessageBox.Show(
            $"Вы действительно хотите отправить документ №{selectedDoc.DocNumber} в архив?",
            "Подтверждение",
            MessageBoxButton.YesNo,
            MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
                return;
            try
            {
                using (var context = new DocControlEntities())
                {
                    var doc = context.Documents.FirstOrDefault(d => d.DocumentID == selectedDoc.DocumentID);
                    if (doc != null)
                    {
                        doc.IsArchive = 1;
                        doc.ArchiveDate = DateTime.Now;
                        context.SaveChanges();
                    }
                }

                MessageBox.Show("Документ успешно отправлен в архив.", "Архивирование", MessageBoxButton.OK, MessageBoxImage.Information);

                // Обновить список исходящих документов
                DataContext = null;
                LoadIncomingDocuments();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при перемещении документа: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void filter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var cvs = (CollectionViewSource)this.Resources["DocsViewSource"];
            cvs.View.Refresh();
        }

        private void DocsViewSource_Filter(object sender, FilterEventArgs e)
        {
            var doc = e.Item as Documents;
            if (doc == null)
            {
                e.Accepted = false;
                return;
            }

            // Фильтр по типу документа
            var selectedType = cmbDocTypes.SelectedItem as DocumentType;
            if (selectedType != null && doc.DocTypeID != selectedType.DocTypeID)
            {
                e.Accepted = false;
                return;
            }

            // Фильтр по дате "с"
            if (dtpStart.SelectedDate.HasValue && doc.DateCreate < dtpStart.SelectedDate.Value)
            {
                e.Accepted = false;
                return;
            }

            // Фильтр по дате "по"
            if (dtpEnd.SelectedDate.HasValue && doc.DateCreate > dtpEnd.SelectedDate.Value)
            {
                e.Accepted = false;
                return;
            }

            e.Accepted = true;
        }
    }
}
