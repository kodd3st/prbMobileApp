﻿using DoControl.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.DataVisualization.Charting;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DoControl.pages.controlPages
{
    /// <summary>
    /// Логика взаимодействия для templatePage.xaml
    /// </summary>
    public partial class templatePage : Page
    {
        public List<Documents> Templates { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public templatePage()
        {
            InitializeComponent();
            LoadTemplates();
        }
        private void LoadTemplates()
        {
            using (var db = new DocControlEntities())
            {
                Templates = db.Documents.Where(d => d.IsTemplate == 1).ToList();
                cmbDocTypes.ItemsSource = db.DocumentType.ToList();
                foreach (var doc in Templates)
                {
                    doc.DocumentType = db.DocumentType.FirstOrDefault(t => t.DocTypeID == doc.DocTypeID);
                    doc.DocumentStatus = db.DocumentStatus.FirstOrDefault(s => s.StatusID == doc.StatusID);
                }
            }
            DataContext = this;
        }

        private void btnCreateTemplate_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new docCreatePage(true));
        }

        private void btnApplyFilter_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new DocControlEntities())
            {
                var query = context.Documents.Where(d => d.IsTemplate == 1);

                // Фильтр по типу документа
                var selectedType = cmbDocTypes.SelectedItem as DocumentType;
                if (selectedType != null)
                {
                    query = query.Where(d => d.DocTypeID == selectedType.DocTypeID);
                }

                // Фильтр по дате "с"
                if (StartDate.HasValue)
                {
                    query = query.Where(d => d.DateCreate >= StartDate.Value);
                }

                // Фильтр по дате "по"
                if (EndDate.HasValue)
                {
                    query = query.Where(d => d.DateCreate <= EndDate.Value);
                }

                Templates = query.ToList();

                foreach (var doc in Templates)
                {
                    doc.DocumentType = context.DocumentType.FirstOrDefault(t => t.DocTypeID == doc.DocTypeID);
                    if (doc.DepartmentID.HasValue)
                    {
                        doc.Departments = context.Departments.FirstOrDefault(d => d.DepartmentID == doc.DepartmentID.Value);
                    }
                    doc.DocumentStatus = context.DocumentStatus.FirstOrDefault(s => s.StatusID == doc.StatusID);
                }
            }
            DataContext = null;
            DataContext = this;
        }

        private void btnCancelFilter_Click(object sender, RoutedEventArgs e)
        {
            StartDate = null;
            EndDate = null;
            cmbDocTypes.SelectedItem = null;
            DataContext = null;
            LoadTemplates();
        }

        private void btnEditTemplate_Click(object sender, RoutedEventArgs e)
        {
            var selected = lstTemplates.SelectedItem as Documents;
            if (selected == null)
            {
                MessageBox.Show("Выберите шаблон для редактирования.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            NavigationService.Navigate(new docCreatePage(selected, true));
        }

        private void btnDeleteTemplate_Click(object sender, RoutedEventArgs e)
        {
            var selected = lstTemplates.SelectedItem as Documents;
            if (selected == null)
            {
                MessageBox.Show("Выберите шаблон для удаления.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var result = MessageBox.Show($"Удалить шаблон '{selected.Title}'?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes) return;

            using (var context = new DocControlEntities())
            {
                var doc = context.Documents.FirstOrDefault(d => d.DocumentID == selected.DocumentID);
                if (doc != null)
                {
                    context.Documents.Remove(doc);
                    context.SaveChanges();
                }
            }
            DataContext = null;
            LoadTemplates();
        }

        private void btnCreateDocFromTemplate_Click(object sender, RoutedEventArgs e)
        {
            var selected = lstTemplates.SelectedItem as Documents;
            if (selected == null)
            {
                MessageBox.Show("Выберите шаблон для создания документа.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            // Открытие страницы создания документа с предзаполнением из шаблона
            NavigationService.Navigate(new docCreatePage(selected, false));
        }
    }
}
