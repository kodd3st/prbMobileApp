﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DoControl.infrastructure;
using DoControl.model;
using DoControl.pages;

namespace DoControl.pages.controlPages
{
    /// <summary>
    /// Логика взаимодействия для dashboardPage.xaml
    /// </summary>
    public partial class dashboardPage : Page
    {
        public List<Documents> newDocuments { get; set; }
        public List<Documents> docsMonth { get; set; }
        public dashboardPage()
        {
            InitializeComponent();
            LoadDocuments();
        }

        private void LoadDocuments()
        {
            try
            {
                txbName.Text += UserSession.Instance.Surname + " " + UserSession.Instance.Name + " " + UserSession.Instance.SecondName;
                int departmentId = UserSession.Instance.DepartmentID;
    
                var oneMonthAgo = DateTime.Now.AddMonths(-1);

                if (departmentId == 9)
                {
                    newDocuments = DBConn.db.Documents.Where(d => d.StatusID == 1 && d.OutInID == 1).ToList();
                    docsMonth = DBConn.db.Documents.Where(d => d.OutInID == 1 && d.DateCreate >= oneMonthAgo).ToList();
                }
                else
                {
                    newDocuments = DBConn.db.Documents.Where(d => d.StatusID == 1 && d.DepartmentID == departmentId).ToList();
                    docsMonth = DBConn.db.Documents.Where(d => d.DateCreate >= oneMonthAgo && d.DepartmentID == departmentId).ToList();
                }
                DataContext = this;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки документов: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void btnAddDoc_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("./pages/controlPages/docCreatePage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void lstLastMonth_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var listView = sender as ListView;
            if (listView?.SelectedItem != null)
            {
                var selectedDoc = listView.SelectedItem;
                // Здесь вызовите метод просмотра документа
                ViewDocument(selectedDoc);
            }
        }

        private void lstNewDocs_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var listView = sender as ListView;
            if (listView?.SelectedItem != null)
            {
                var selectedDoc = listView.SelectedItem;
                // Здесь вызовите метод просмотра документа
                ViewDocument(selectedDoc);
            }
        }
        private void ViewDocument(object doc)
        {
            // Реализуйте открытие окна просмотра или переход на страницу документа
            MessageBox.Show($"Просмотр документа: {doc}");
        }
    }
}
